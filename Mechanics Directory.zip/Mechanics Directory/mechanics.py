import turtle
import time
import random
def pos_forward(angle):
    turtle.forward(angle)
def pos_angleright(angle):
    turtle.right(angle)
def pos_angleleft(angle):
    turtle.left(angle)
def pos_backward(angle):
    turtle.backward(angle)
def infinite_backandforth(number):
    while(True):
        turtle.forward(number)
        turtle.backward(number)
def infinite_backandforth_angle(number, angle):
    while(True):
        turtle.forward(number);pos_angleright(angle)
        turtle.backward(number);pos_angleleft(angle)
def shape(name):
    turtle.shape(name)
    turtle.fd(0)
    turtle.exitonclick()
def title(name):
    turtle.title(name)
def par_text(color, thickness):
    turtle.color(color)
    turtle.pensize(thickness)
def setcolor(color):
    turtle.color(color)
def timecolor(color, color2, color3, color4, color5):
    turtle.color(color)
    time.sleep(1)
    turtle.color(color2)
    time.sleep(1)
    turtle.color(color3)
    time.sleep(1)
    turtle.color(color4)
    time.sleep(1)
    turtle.color(color5)
    time.sleep(1)
def infinite_timecolor(color, color2, color3, color4, color5):
    while(True):
        turtle.color(color)
        time.sleep(1)
        turtle.color(color2)
        time.sleep(1)
        turtle.color(color3)
        time.sleep(1)
        turtle.color(color4)
        time.sleep(1)
        turtle.color(color5)
        time.sleep(1)
def infinite_randomcolor_timecolor(color, color2, color3, color4, color5):
    while(True):
        turtle.color(color + round(random.uniform(1,5)))
        time.sleep(1)
def createRec(width, height):
        pos_angleleft(90)
        turtle.forward(height)
        pos_angleright(90)
        turtle.forward(width)
        pos_angleright(90)
        turtle.forward(height)
        pos_angleleft(-90)
        turtle.forward(width)
        pos_angleleft(-90)
def infinite_createRec(width, height):
    while(True):
        pos_angleleft(90)
        turtle.forward(height)
        pos_angleright(90)
        turtle.forward(width)
        pos_angleright(90)
        turtle.forward(height)
        pos_angleleft(-90)
        turtle.forward(width)
        pos_angleleft(-90)
def close():
    turtle.bye()
def foursquares():
    for i in range(4):
        createRec(50,50)
    close()
def drawsquares(number):
    for i in number:
        createRec(50,50)
    close()